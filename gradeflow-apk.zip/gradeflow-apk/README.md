# GradeFlow Android APK (via GitHub Actions)

1. Create a new GitHub repo and upload everything in this folder (keep `.github/workflows/build-apk.yml`).
   Easiest: unzip, then on github.com use "Add file > Upload files" and drag all contents in, including the hidden `.github` folder.
2. Open the repo's **Actions** tab. The "Build Android APK" workflow runs on every push (or press "Run workflow").
3. When it finishes (about 5-8 min), open the run and download the **GradeFlow-apk** artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone, allow "Install unknown apps", and install.

Notes
- This is a debug-signed APK: fine for installing on your own/school devices, but not accepted by Google Play. For Play Store, add a release keystore.
- The app bundles the web files in `www/`. To update the app, edit `www/index.html`, push, and rebuild.
- Payment return (`?payment=...`): Finivex redirects to a web URL, which opens in the phone's browser rather than the app.
